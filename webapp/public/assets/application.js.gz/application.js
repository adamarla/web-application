// The recommended practice is not to include any JS code 
// in a manifest file - like this one. Instead, split JS code 
// in other .js files and require them as needed
